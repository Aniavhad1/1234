console.log("Static site loaded successfully!");
