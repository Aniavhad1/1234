# Assignment 1B

This project consists of a frontend and backend implementation for managing user data.

## Project Structure

- `backend/` - Contains the Node.js Express backend server and data file.
- `frontend/` - Contains the frontend HTML, CSS, and JavaScript files.

## Prerequisites

- Node.js installed on your system.
- Internet browser to open the frontend.

## Backend Setup and Run

1. Open a terminal and navigate to the `Assignment_1B/backend` directory.
2. Install dependencies (if not already installed):
   ```
   npm install
   ```
3. Ensure the `data.json` file exists in the `backend` directory with valid JSON content (e.g., an empty array `[]` or some dummy user data).
4. Start the backend server:
   ```
   node server.js
   ```
5. The backend server will run at `http://localhost:3000`.

## Frontend Setup and Run

1. Open the `Assignment_1B/frontend/index.html` file in your preferred web browser.
2. The frontend will fetch user data from the backend server at `http://localhost:3000/users`.
3. You can add new users using the form on the frontend, which will send POST requests to the backend.

## Notes

- Make sure the backend server is running before opening the frontend to avoid errors.
- The backend uses CORS to allow requests from the frontend.
- The user data is stored in the `data.json` file in the backend directory.

## Troubleshooting

- If you encounter errors related to reading or writing data, verify that the `data.json` file exists and has proper read/write permissions.
- If the frontend shows JSON parsing errors, ensure the backend server is running and accessible at `http://localhost:3000`.
