const express = require("express");
const fs = require("fs");
const cors = require("cors");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const path = require("path");
console.log(path);
const dataPath = path.resolve(__dirname, "data.json");
console.log(dataPath);

console.log("Current working directory:", process.cwd());
console.log("Resolved dataPath:", dataPath);

// Get users
app.get("/users", (req, res) => {
  fs.readFile(dataPath, (err, data) => {
    if (err) return res.status(500).send("Error reading data");
    res.json(JSON.parse(data));
  });
});

// Add user
app.post("/users", (req, res) => {
  fs.readFile(dataPath, (err, data) => {
    if (err) return res.status(500).send("Error reading data");

    const users = JSON.parse(data);
    users.unshift(req.body);

    fs.writeFile(dataPath, JSON.stringify(users, null, 2), (err) => {
      if (err) return res.status(500).send("Error writing data");
      res.status(201).json(req.body);
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
