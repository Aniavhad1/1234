const API_URL = "http://localhost:3000/users";

function fetchData() {
  fetch(API_URL)
    .then((res) => res.json())
    .then((data) => {
      localStorage.setItem("users", JSON.stringify(data));
      displayData();
    });
}

function displayData() {
  const tbody = document.getElementById("tbody");
  const users = JSON.parse(localStorage.getItem("users")) || [];

  tbody.innerHTML = users
    .map(
      (user, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${user.name}</td>
      <td>${user.username}</td>
      <td>${user.email}</td>
      <td>${user.phone}</td>
      <td>${user.address?.city || user.city}</td>
    </tr>
  `
    )
    .join("");
}

document.getElementById("userForm").addEventListener("submit", (e) => {
  e.preventDefault();

  const user = {
    name: document.getElementById("name").value,
    username: document.getElementById("username").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    city: document.getElementById("city").value,
    password: document.getElementById("password").value,
    address: {
      city: document.getElementById("city").value,
    },
  };

  fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(user),
  })
    .then((res) => res.json())
    .then((newUser) => {
      const users = [
        newUser,
        ...JSON.parse(localStorage.getItem("users") || "[]"),
      ];
      localStorage.setItem("users", JSON.stringify(users));
      displayData();
      document.getElementById("userForm").reset();
      const modal = bootstrap.Modal.getInstance(
        document.getElementById("addUserModal")
      );
      modal.hide();
    });
});

fetchData();
