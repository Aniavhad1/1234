## How to Run

1. Open the `index.html` file in any modern web browser.
2. The dashboard will be displayed with all its features.
