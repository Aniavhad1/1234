Open the Website in a Browser
run a live server.
The website will automatically adjust for mobile screens.
