Install Docker
For Windows: Download Docker Desktop from https://www.docker.com/products/docker-desktop
Install and launch Docker Desktop
Docker Desktop should be running in the background

## Setup and Run

To set up and run this project, follow these steps:

1. Install dependencies:

```bash
npm install
```

2. Start the server:

```bash
npm start
```

This will run the server using `node server.js`. The server uses Express.js and will start listening on the configured port.

Stop this server as we need to run the same using Docker which will show same result
Follow below step to run from docker

## Docker

To build and run the Docker container, use the following commands:

1. Build the Docker image:

```bash
docker build -t assignment_2b .
```

2. Run the Docker container:

```bash
docker run -p 3000:3000 assignment_2b
```

This will expose the server on port 3000.
