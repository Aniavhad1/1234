## Setup and Run

To set up and run this project, follow these steps:
Install dependencies, run:
npm install

## Development server

To start a local development server, run:
ng serve

Once the server is running, open your browser and navigate to `http://localhost:4200/`. The application will automatically reload whenever you modify any of the source files.
